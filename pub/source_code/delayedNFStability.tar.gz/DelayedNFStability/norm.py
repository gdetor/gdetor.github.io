# Copyright (c) 2014, Georgios Is. Detorakis (gdetor@gmail.com)
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# This file computes the norm for a given synaptic matrix and a firing rate
# slope parameter. This work appears in:
# Georgios Is. Detorakis, Antoine Chaillet, Ihab Haidar, "A Global Stability
# Analysis for Delayed Neural Fields", BCCN,
# Goettingen, Germany, 2014.
import sys
import struct
import numpy as np


def gaussian(x, sigma=1.0):
    ''' Gaussian function '''
    return 1.0/(np.sqrt(2.0*np.pi*sigma**2)) * np.exp(-x**2/(2.0*sigma**2))


def read_C_binfile(fileName):
    with open(fileName, mode='rb') as file:
        fileContent = file.read()

    data = struct.unpack("d" * (len(fileContent)//8), fileContent)
    return np.array(data)


if __name__ == '__main__':
    n = int(sys.argv[1])

    mu = np.tile(np.array([float(sys.argv[2]), float(sys.argv[3])]), 2)

    L = mu/4.0
    q = 1./float(n*n)

    fileName = ['exc-exc', 'exc-inh', 'inh-exc', 'inh-inh']

    D = np.zeros((n*n, n*n))
    tmp = np.zeros((n, n))

    norm = 0.0
    for k in range(4):
        D = np.fromfile(fileName[k], dtype=np.float).reshape(n*n, n*n)
        ii = 0
        for p in range(n):
            for z in range(n):
                tmp[p, z] = ((D[ii, ...].reshape(n, n)).sum(axis=1).sum(axis=0)
                             * q)
                ii += 1
        norm += L[k]**2 * (tmp.sum(axis=1).sum(axis=0))*q

    print 2.0 * norm
