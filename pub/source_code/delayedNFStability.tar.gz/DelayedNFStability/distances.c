/*
 * Copyright (c) 2014, Georgios Is. Detorakis (gdetor@gmail.com)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/* A struct that contains the number of nodes, the size of the discretization,
 * the grid X and the grid Y. 
 */
struct grid{
    int nodes;
    int size;
    double *x;
    double *y;
};

typedef struct grid mgrid;

/* Fundtion arange returns a one-dimensional discrete grid. It discretizes the
 * interval [a, b] into step points.
 */
int arange(double a, double b, double **c, double step)
{
    int i = 0, ii = 0;
    int iters = (int)(b - a)/step;
    double *tmp;

    tmp = (double *)malloc(iters * sizeof(double));

    for(i = 0; i < iters; i++){
        tmp[i] =  a + ii * step; 
        ii++;
    }
    *c = tmp;
    
    return iters;
}

/* Function meshgrid returns the X and Y two-dimensional grids */
void meshgrid(mgrid grid, double *x, double *y)
{
    int i, j;

    for(i = 0; i < grid.nodes; i++){
        for(j = 0; j < grid.nodes; j++){
            grid.x[i*grid.nodes+j] = x[j];
            grid.y[i*grid.nodes+j] = y[i];
        }
    }
}

/* Just a gaussian function! */
double gaussian(double x, double sigma)
{
    return 1./(sqrt(2.0 * M_PI * sigma*sigma)) * exp(-(x*x)/(2.0*sigma*sigma));
}

/* Writes to a binary file! */
int write2file(char *filename, double **data, int size)
{
    int i;
    double *tmp;

    FILE *fp;

    if(!(fp = fopen(filename, "wb"))){
        printf("Error! File cannot be opened!\n");
        return -1;
    }

    tmp = (double *)malloc(size * size * sizeof(double));

    for(i = 0; i < size; i++){
        memcpy(&tmp[i*size], &data[i][0], sizeof(double)*size); 
    }

    fwrite(tmp, sizeof(double), size*size, fp);
    fclose(fp);

    return 0;
}

int main(int argc, char**argv)
{
    int i, j, k, size = 0, nodes = atoi(argv[1]);
    double length = 2.0, center = 0.0;
    double x_inf, x_sup, y_inf, y_sup;
    double cx, cy, dx, dy, nx, ny;
    double *x, *y;
    double **D;

    double K[4] = {10.*2.0, -10.*sqrt(2), 10.*sqrt(2), -10.*2.0};
    double Sigma[4] = {1.0, 0.1, 0.1, 1.0};
    
    char filenames[4][10] = {"exc-exc", "exc-inh", "inh-exc", "inh-inh"};

    mgrid g;
    g.nodes = nodes;

    x_inf = -length/2.0;
    x_sup = length/2.0;
    y_inf = -length/2.0;
    y_sup = length/2.0;
    cx = 0.0;
    cy = 0.0;
    dx = length/(double)nodes;
    dy = length/(double)nodes;
    nx = (x_sup - x_inf)/dx;
    ny = (y_sup - y_inf)/dy;

    size = arange(x_inf, x_sup, &x, dx);
    size = arange(y_inf, y_sup, &y, dy);

    g.size = size;
    g.x = (double *)malloc(nodes * nodes * sizeof(double));
    g.y = (double *)malloc(nodes * nodes * sizeof(double));

    D = (double **)malloc(nodes*nodes*sizeof(double *));
    for(i = 0; i < nodes*nodes; i++){
        D[i] = (double *)malloc(nodes*nodes*sizeof(double));
    }

    meshgrid(g, x, y);

    /* This is the actual computation of the distances matrix D */
    for(k = 0; k < 4; k++){
        for(i = 0; i < nodes*nodes; i++){
            for(j = 0; j < nodes*nodes; j++){
                D[i][j] = pow(K[k] * gaussian(sqrt((g.x[i]-center)*(g.x[i]-center) 
                                               + (g.y[j]-center)*(g.y[j]-center)),
                                               Sigma[k]), 2.0);
            }
        }
        write2file(filenames[k], D, nodes*nodes);
    }

    /* Memory deallocation */
    for(i = 0; i < size*size; i++){
        free(D[i]);
    }
    free(D);
    free(g.x);
    free(g.y);
    free(x);
    free(y);

    return 0;
}
