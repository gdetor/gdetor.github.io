# Copyright (c) 2014, Georgios Is. Detorakis (gdetor@gmail.com)
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# This file plots all the Figures appear in:
# Georgios Is. Detorakis, Antoine Chaillet, Ihab Haidar, "A Global Stability
# Analysis for Delayed Neural Fields", BCCN,
# Goettingen, Germany, 2014.
import numpy as np
import matplotlib.pylab as plt
from mpl_toolkits.mplot3d import Axes3D


def plot_all(x1, x2, x1_proj, x2_proj, params, size, time, dt=.01, part=0):
    x1_proj /= x1_proj.max()
    x2_proj /= x2_proj.max()

    step = 50
    Y, X = np.meshgrid(np.linspace(-1, 1, size),
                       np.linspace(0, time, int(time/dt)))
    if part == 0:
        pms_exc = 'Exc. population: c='+str(params[0][0]) + \
                  ', m='+str(params[1][0])+', tau='+str("%.2f" % params[2][0])

        pms_inh = 'Inh. population: c='+str(params[0][1]) + \
                  ', m='+str(params[1][1])+', tau='+str("%.2f" % params[2][1])

        plt.figure(figsize=(11, 5))
        plt.subplots_adjust(wspace=.1, hspace=.1)

        ax = plt.subplot2grid((2, 2), (0, 0), rowspan=2)
        ax.plot(x1, c='r', lw=2, label='Exc')
        ax.plot(x2, c='b', lw=2, label='Inh')

        x_max = max(x1.max(), x2.max())
        x_min = min(x1.min(), x2.min())
        ax.set_xlim(-0.05, x1.shape[0])
        ax.set_ylim(x_min-.2, x_max+.2)
        ax.set_xticks([0, x1.shape[0]//2, x1.shape[0]])
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(handles, labels, loc=7)
        ax.set_xticklabels(('0', '12.5', '25'))
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Maximal value of Ue and Ui')

        ax.text(300, 4, pms_exc,
                fontsize=10,
                va='bottom',
                ha='left',
                weight='bold')
        ax.text(300, 3, pms_inh,
                fontsize=10,
                va='bottom',
                ha='left',
                weight='bold')

        # -----------------------------------

        ax = plt.subplot2grid((2, 2), (0, 1), projection='3d')
        surf = ax.plot_surface(X[::50, :], Y[::50, :], x1_proj[::50, :],
                               rstride=1, cstride=1,
                               cmap=plt.cm.coolwarm,
                               linewidth=0, antialiased=False)
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Space')
        ax.set_zlabel('Amplitude of projection')

        ax.set_xticks([0, step//4, step//2])
        ax.set_xticklabels(('0', '12.5', '25'))
        ax.set_yticks([])

        # -----------------------------------

        ax = plt.subplot2grid((2, 2), (1, 1), projection='3d')
        surf = ax.plot_surface(X[::step, :], Y[::step, :], x2_proj[::step, :],
                               rstride=1, cstride=1,
                               cmap=plt.cm.coolwarm,
                               linewidth=0, antialiased=False)

        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Space')
        ax.set_zlabel('Amplitude of projection')

        ax.set_xticks([0, step//4, step//2])
        ax.set_xticklabels(('0', '12.5', '25'))
        ax.set_yticks([])

        # -----------------------------------

    elif part == 1:
        ax = plt.subplot2grid((2, 1), (0, 0), rowspan=2)
        im = ax.imshow(x1_proj, interpolation='bicubic', cmap=plt.cm.jet,
                       vmin=0, vmax=1, aspect=1./25.)
        ax.set_xlabel('Space')
        ax.set_ylabel('Time')
        ax.set_xticks([])
        ax.set_yticks([0, int(time/dt)//2, int(time/dt)])
        ax.set_yticklabels(('0', '12.5', '25'))
        plt.colorbar(im)

        # -----------------------------------
    else:
        ax = plt.subplot2grid((2, 1), (0, 0), rowspan=2)
        im = ax.imshow(x2_proj, interpolation='bicubic', cmap=plt.cm.jet,
                       aspect=1./25.)
        ax.set_xlabel('Space')
        ax.set_ylabel('Time')
        ax.set_xticks([])
        ax.set_yticks([0, int(time/dt)//2, int(time/dt)])
        ax.set_yticklabels(('0', '12.5', '25'))
        plt.colorbar(im)

if __name__ == '__main__':
    c = np.array([.2, .5])          # Velocity of action potential (m/s)
    slope = np.array([3., 3.])    # Slope of sigmoid function
    tau = np.array([1./3., 1./4.])      # Temporal decay of synapse

    V = []
    F = ['exc-act', 'inh-act', 'exc-evo', 'inh-evo', 'exc-prj', 'inh-prj']
    for i in F:
        V.append(np.load(i+'.npy'))

    Ve, Vi = V[0], V[1]
    Ve_, Vi_ = V[2], V[3]
    Ve_proj, Vi_proj = V[4], V[5]

    plot_all(Ve_, Vi_, Ve_proj, Vi_proj, [c, slope, tau], 64, 25.0, part=0)

    plt.savefig('stable-unsta-evo.pdf')

    plt.show()
