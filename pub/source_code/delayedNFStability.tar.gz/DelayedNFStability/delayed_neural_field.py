# Copyright (c) 2014, Georgios Is. Detorakis (gdetor@gmail.com)
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# This file solves numerically a two populations delayed neural field equation
# for a given synaptic matrix and a firing rate slope parameter. This work
# appears in:
# Georgios Is. Detorakis, Antoine Chaillet, Ihab Haidar, "A Global Stability
# Analysis for Delayed Neural Fields", BCCN,
# Goettingen, Germany, 2014.
# IMPORTANT: The core code is taken by the work of Axel Hutt and Nicolas P.
# Rougier and it firstly appeared in:
# Axel Hutt and Nicolas P. Rougier, "Activity spread and breathers induced
# by finite transmission speeds in two-dimensional neural fields", Physical
# Review E, 82(5), pp.055701, 2010.
# The source code of Hutt and Rougier is given here:
# http://www.loria.fr/~rougier/downloads/DNF.py

import sys
import time
import exceptions
import numpy as np
import matplotlib.pyplot as plt
from numpy.fft import rfft2, irfft2, fftshift

np.random.seed(30)


class delayed_neural_field(object):
    def __init__(self, domain, nodes, time, dt, K, Sigma, tau, c, slope):
        self.l = domain
        self.n = nodes
        self.t = time
        self.dt = dt
        self.m_e = slope[0]
        self.m_i = slope[1]
        self.tau_e = tau[0]
        self.tau_i = tau[1]
        self.tau_m = tau.max()
        self.c_e = c[0]
        self.c_i = c[1]
        self.L = slope/4.0

        # Domain discretization
        D, dx, dy = self.discretization()

        # Generation of external input
        self.I_ext = 2. * self.gaussian(D, 0.1)

        # Generation of kernels
        self.Wee = K[0] * self.gaussian(D, Sigma[0])
        self.Wei = K[1] * self.gaussian(D, Sigma[1])
        self.Wie = K[2] * self.gaussian(D, Sigma[2])
        self.Wii = K[3] * self.gaussian(D, Sigma[3])

        self.Wee *= (dx * dy)
        self.Wei *= (dx * dy)
        self.Wie *= (dx * dy)
        self.Wii *= (dx * dy)

        # Generate kernel rings
        self.nrings_e, self.nrings_i = self.kernel_onions_fft()

    def disc(self, shape=(256, 256), center=None, radius=64):
        ''' Generate a numpy array containing a disc.

        :Parameters:
            `shape` : (int,int)
                Shape of the output array
            `center`: (int,int)
                Disc center
            `radius`: int
                Disc radius (if radius = 0 -> disc is 1 point)
        '''
        if not center:
            center = (shape[0]//2, shape[1]//2)

        def distance(x, y):
            return np.sqrt((x-center[0])**2+(y-center[1])**2)
        D = np.fromfunction(distance, shape)
        return np.where(D <= radius, True, False).astype(np.float32)

    def peel(self, Z, center=None, r=8):
        ''' Peel an array Z into several 'onion rings' of width r.

        :Parameters:
            `Z`: numpy.ndarray
                Array to be peeled
            `center`: (int,int)
                Center of the 'onion'
            `r` : int
                ring radius
        :Returns:
            `out` : [numpy.ndarray,...]
                List of n Z-onion rings with n >= 1
        '''
        if r <= 0:
            raise exceptions.ValueError('Radius must be > 0')
        if not center:
            center = (Z.shape[0]//2, Z.shape[1]//2)
        if (center[0] >= Z.shape[0] or center[1] >= Z.shape[1] or center[0] < 0
                or center[1] < 0):
            raise exceptions.ValueError('Center must be in the matrix')

        # Compute the maximum diameter to get number of rings
        dx = float(max(Z.shape[0]-center[0], center[0]))
        dy = float(max(Z.shape[1]-center[1], center[1]))
        radius = np.sqrt(dx**2 + dy**2)

        # Generate 1+int(d/r) rings
        L = []
        K = Z.copy()
        n = 1 + int(radius/r)
        for i in range(n):
            r1 = (i) * r/2
            r2 = (i+1) * r/2
            K = ((self.disc(Z.shape, center, 2*r2) -
                  self.disc(Z.shape, center, 2*r1)) * Z)
            L.append(K)
        L[0][center[0], center[1]] = Z[center[0], center[1]]
        return L

    def discretization(self):
        x_inf, x_sup, dx = -self.l/2, +self.l/2, self.l/float(self.n)
        y_inf, y_sup, dy = -self.l/2, +self.l/2, self.l/float(self.n)
        nx, ny = (x_sup - x_inf)/dx, (y_sup - y_inf)/dy
        X, Y = np.meshgrid(np.arange(x_inf, x_sup, dx),
                           np.arange(y_inf, y_sup, dy))
        D = np.sqrt(X**2 + Y**2)
        return D, dx, dy

    def kernel_onions_fft(self):
        r_e = max(1, self.c_e * self.dt * self.n/self.l)
        r_i = max(1, self.c_i * self.dt * self.n/self.l)
        self.Wee = self.peel(self.Wee, center=(self.n//2, self.n//2), r=r_e)
        self.Wei = self.peel(self.Wei, center=(self.n//2, self.n//2), r=r_i)
        self.Wii = self.peel(self.Wii, center=(self.n//2, self.n//2), r=r_i)
        self.Wie = self.peel(self.Wie, center=(self.n//2, self.n//2), r=r_e)
        nrings_e, nrings_i = len(self.Wee), len(self.Wii)   # Number of rings

        # Precompute Fourier transform for each kernel ring since they're
        # only used in the Fourier domain
        self.Wee = [rfft2(fftshift(self.Wee[i])) for i in range(nrings_e)]
        self.Wei = [rfft2(fftshift(self.Wei[i])) for i in range(nrings_i)]
        self.Wii = [rfft2(fftshift(self.Wii[i])) for i in range(nrings_i)]
        self.Wie = [rfft2(fftshift(self.Wie[i])) for i in range(nrings_e)]
        return nrings_e, nrings_i

    def gaussian(self, x, sigma=1.0):
        ''' Gaussian function '''
        return 1.0/(np.sqrt(2.0*np.pi*sigma**2)) * np.exp(-x**2/(2.0*sigma**2))

    def sigmoid(self, x, mu):
        return 1./(1. + np.exp(-x*mu))

    def run(self):
        # Initial state (t <= 0)
        # Ve_0, Vi_0 = np.random.random()*1e-12, np.random.random()*1e-11
        # Ve = np.ones((self.n, self.n)) * Ve_0
        # Vi = np.ones((self.n, self.n)) * Vi_0
        Ve = np.random.uniform(0, 1, (self.n, self.n))
        Vi = np.random.uniform(0, 1, (self.n, self.n))

        # Initialisation
        # ---------------
        self.Ue = [rfft2(self.sigmoid(Ve, self.m_e)), ] * self.nrings_e
        self.Ui = [rfft2(self.sigmoid(Vi, self.m_i)), ] * self.nrings_i

        Ve_proj = np.zeros((int(self.t/self.dt), self.n))
        Vi_proj = np.zeros((int(self.t/self.dt), self.n))

        Ve_, Vi_ = [], []

        # Integrate the model
        for i in range(0, int(self.t/self.dt)):
            Lee = self.Wee[0] * self.Ue[0]
            Lei = self.Wei[0] * self.Ui[0]
            Lie = self.Wie[0] * self.Ue[0]
            Lii = self.Wii[0] * self.Ui[0]

            for j in range(1, self.nrings_e):
                Lee += self.Wee[j] * self.Ue[j]
                Lie += self.Wie[j] * self.Ue[j]

            for j in range(1, self.nrings_i):
                Lei += self.Wei[j] * self.Ui[j]
                Lii += self.Wii[j] * self.Ui[j]

            Lee, Lei = irfft2(Lee).real, irfft2(Lei).real
            Lie, Lii = irfft2(Lie).real, irfft2(Lii).real

            Ve += self.dt/self.tau_e * (-Ve + Lee + Lei + self.I_ext)
            Vi += self.dt/self.tau_i * (-Vi + Lie + Lii + self.I_ext)

            self.Ue = ([rfft2(self.sigmoid(Ve, self.m_e)), ] + self.Ue[:-1])
            self.Ui = ([rfft2(self.sigmoid(Vi, self.m_i)), ] + self.Ui[:-1])

            Ve_.append(Ve.max())
            Vi_.append(Vi.max())

            Ve_proj[i, ...] = Ve.sum(axis=0)
            Vi_proj[i, ...] = Vi.sum(axis=0)
        return Ve, Vi, np.array(Ve_), np.array(Vi_), Ve_proj, Vi_proj


def plot_solution(x1, x2):
    fig = plt.figure(figsize=(8, 3))
    ax = fig.add_subplot(121)
    im = ax.imshow(x1, interpolation='bicubic', cmap=plt.cm.jet, vmin=0,
                   vmax=1)
    ax.set_xticks([])
    ax.set_yticks([])
    plt.colorbar(im)

    ax = fig.add_subplot(122)
    im = ax.imshow(x2, interpolation='bicubic', cmap=plt.cm.jet, vmin=0,
                   vmax=1)
    ax.set_xticks([])
    ax.set_yticks([])
    plt.colorbar(im)


# -----------------------------------------------------------------------------
if __name__ == '__main__':
    # Parameters
    # ----------
    domain_size = 2.00   # Size of the field (mm)
    nodes = 64           # Space discretization
    t = 25.              # Duration of simulation (in seconds)
    dt = .01             # Temporal discretisation (in seconds)

    scale = 1.0

    c = np.array([.2, .5])          # Velocity of action potential (m/s)
    slope = np.array([3., 3.])    # Slope of sigmoid function
    tau = np.array([1./3, 1./4.])      # Temporal decay of synapse

    # Kernel amplitudes and variances matrices
    # Stable
    K = np.array([2.0, -np.sqrt(2), np.sqrt(2), -2.0]) * scale
    Sigma = np.array([1.0, 0.1, 0.1, 1.0])

    # Unstable
    # K = np.array([50.2, -50.2, 20.09, -20.09])
    # Sigma = np.array([0.1, 0.1, 1.0, 1.0])

    base = '/Users/gdetorak/Results/'

    tmp_ = []
    if sys.argv[1] == 'run':
        t0 = time.clock()
        for k in range(1):
            # slope = np.random.randint(0, 20, (2,))
            # tau = np.random.uniform(0, 5, (2,))
            # c = np.random.uniform(0, 1000, (2,))
            dnf = delayed_neural_field(domain_size, nodes, t, dt, K, Sigma,
                                       tau, c, slope)

            Ve, Vi, Ve_, Vi_, Ve_proj, Vi_proj = dnf.run()
            V = [Ve, Vi, Ve_, Vi_, Ve_proj, Vi_proj]
            F = ['exc-act', 'inh-act', 'exc-evo', 'inh-evo', 'exc-prj',
                 'inh-prj']

            for i, j in enumerate(V):
                np.save(F[i], j)
                # np.save(base+F[i]+str('%03d' % k), j)

        tf = time.clock()
        print 'Total time (in s) of simulation: {}'.format(tf-t0)
            # tmp_.append(c)
        # np.savetxt(base+'params.pms', tmp_)
    if sys.argv[1] == 'plot':
        V = []
        F = ['exc-act', 'inh-act', 'exc-evo', 'inh-evo', 'exc-prj', 'inh-prj']
        for i in F:
            V.append(np.load(i+'.npy'))
