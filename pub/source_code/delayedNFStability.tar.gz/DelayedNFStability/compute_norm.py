# Copyright (c) 2014, Georgios Is. Detorakis (gdetor@gmail.com)
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# This file computes the norm for a given synaptic matrix and a firing rate
# slope parameter. This work appears in:
# Georgios Is. Detorakis, Antoine Chaillet, Ihab Haidar, "A Global Stability
# Analysis for Delayed Neural Fields", BCCN,
# Goettingen, Germany, 2014.
import os
import subprocess

if __name__ == '__main__':
    num_neurons = 64
    mu_e, mu_i = 3., 3.

    print 'Constructing the distances...'
    subprocess.call(["gcc", "-O2", "-O3", "grids.c"])
    subprocess.call(["./a.out", str(num_neurons)])

    print 'Computing the norm...'
    subprocess.call(["python", "norm.py", str(num_neurons), str(mu_e),
                     str(mu_i)])

    print 'Cleaning up the folder!'
    os.remove("a.out")
    os.remove("exc-exc")
    os.remove("exc-inh")
    os.remove("inh-exc")
    os.remove("inh-inh")
